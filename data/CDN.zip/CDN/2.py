import requests

def upload_file(file_path, upload_url):
    with open(file_path, 'rb') as file:
        files = {'file': file}
        
        response = requests.post(upload_url, files=files)
        if response.status_code == 200:
            print(response.text)
        else:
            print("Failed to upload file")

if __name__ == "__main__":
    file_path = "test.txt"
    
    upload_url = "http://127.0.0.1:5000/upload"  
    
    upload_file(file_path, upload_url)
