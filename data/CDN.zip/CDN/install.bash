#!/bin/bash
update_config() {
    read -p "$1: " value
    sed -i "s/\"$2\": .*/\"$2\": \"$value\",/" data/config.json
}

setup_ssl() {
    if [ ! -f "/etc/ssl/certs/mycert.pem" ]; then
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/ssl/private/mykey.pem -out /etc/ssl/certs/mycert.pem
    fi
}

update_config "Введите почту администратора" "mail"
update_config "Введите домен" "domain"
update_config "Введите порт" "port"

read -p "Использовать SSL? (да/нет): " use_ssl
if [ "$use_ssl" == "да" ]; then
    sed -i "s/\"protocol\": .*/\"protocol\": \"https\",/" data/config.json
    setup_ssl
else
    sed -i "s/\"protocol\": .*/\"protocol\": \"http\",/" data/config.json
fi

chmod +x main.py

pip install -r requirements.txt

cat > /etc/systemd/system/flask_app.service <<EOF
[Unit]
Description=Flask App
After=network.target

[Service]
User=root
WorkingDirectory=$(pwd)
ExecStart=$(which python) main.py
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable flask_app
systemctl start flask_app

echo "Установка завершена."
